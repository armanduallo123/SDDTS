/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package General;
import java.sql.*;
/**
 *
 * @author jetro
 */
public class StudentBackgroundList{
    public void query(){
         String getQuery = "SELECT * FROM student_user";
    }
}
